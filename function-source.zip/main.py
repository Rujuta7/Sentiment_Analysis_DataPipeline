import vertexai
from vertexai.generative_models import GenerativeModel, Part, FinishReason
import vertexai.preview.generative_models as generative_models
import google.cloud.bigquery as bigquery
from google.cloud import storage

PROJECT_ID="sentimentanalysis-427418"
LOCATION="us-central1"
BUCKET_NAME="customer_sentimentanalysis"

vertexai.init(project="sentimentanalysis-427418", location="us-central1")

def generate_content(question,content):
  model = GenerativeModel("gemini-pro")
  responses = model.generate_content([question,content],generation_config = {"max_output_tokens": 256,"temperature": 0.2,"top_p": 0.8})

  return responses.candidates[0].content.parts[0].text

def read_file(filename):
  with open(filename,'r') as f:
    return f.read()

def generate_and_load(event,context):
  filename=event["name"]

  storage_client=storage.Client()

  bucket=storage_client.bucket(BUCKET_NAME)

  blob=bucket.blob(filename)
  content=blob.download_as_text()
  question="Customer sentiment in the below conversation with reason in format Customer Sentiment: & and in newline reason. Use only the information from the conversation"
  generated_response=generate_content(question,content)
  sentiment=generated_response.split('\n\n')[0].split(':')[1]
  reason=generated_response.split('\n\n')[1].split(':')[1]

  client=bigquery.Client()
  dataset_id="customer_sentiment"
  table_id="sentiment"
  table_ref=client.dataset(dataset_id).table(table_id)
  table=client.get_table(table_ref)

  rows_to_insert=[{'Ticket':filename,'Sentiment': sentiment,'Reason':reason}]
  errors=client.insert_rows(table,rows_to_insert)

  if errors==[]:
    print(f"Data from (filename) inserted successfully")
  else:
    print(f"Encountered error while inserting data from (filename):",errors)
